# паттерны для разных валидаций
# r'^[\w\.-]+@[\w\.-]+\.\w+$' - почта
# r'^\+7\(\d{3}\)\d{3}-\d{2}-\d{2}$' - телефон для формата +7(999)123-45-67
# r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$' - пароль 8 символов 1 буква 1 цифра
# r'^https?://[\w\.-]+\.\w+$'  - url ссылка
# r'^\d{2}\.\d{2}\.\d{4}$'  - формат даты но не проверяет наличие даты в календаре
# r'^(\d{1,3}\.){3}\d{1,3}$' - ip адресс
# r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$' - mac адрес
# r'^\d{4} \d{6}$' -  номер и серия паспорт
import requests
import re
from tkinter import *
from tkinter import ttk
from docx import Document


url = "http://127.0.0.1:4444/TransferSimulator/fullName"

send_url = None

pattern = r'[А-Яа-яёЁ]+ [А-Яа-яёЁ]+ [А-Яа-яёЁ]+'

win = Tk()
win.title("Валидация данных")
win.resizable(False, False)
padx = 20
pady = 20

def send_result():
    doc = Document("rezult.docx")
    table = doc.tables[0]
    row = table.add_row().cells

    row[0].text = lbl_check.cget("text")
    row[1].text = label_result.cget("text")
    row[2].text = "Успешно"
    doc.save("rezult.docx")



def get_data():
    try:
        resp = requests.get(url, timeout=5)
        resp.raise_for_status()
        data = resp.json()
        full_name = data.get('value', '')
        name_var.set(full_name or "Пустая строка")
    except Exception as e:
        name_var.set("Ошибка получения данных")
        result_var.set(str(e))
        label_result.config(foreground="red")
        return

    if re.fullmatch(pattern, full_name):
        result_var.set("Валидные данные")
        label_result.config(foreground="green")
    else:
        result_var.set("ФИО содержит запрещённые символы")
        label_result.config(foreground="red")

main_frame = ttk.Frame(win, padding=(padx, pady))
buttons_frame = ttk.Frame(main_frame)
btn_get = ttk.Button(buttons_frame, text="Получить данные",command=get_data)
btn_send = ttk.Button(buttons_frame, text="Отправить результат теста",command=send_result)
display_frame = ttk.Frame(main_frame)
lbl_fio = ttk.Label(display_frame, text="Полученные данные:")
name_var = StringVar(value="—")
lbl_check = ttk.Label(display_frame, textvariable=name_var, foreground="black", font=("TkDefaultFont", 10, "bold"))
result_var = StringVar(value="—")
label_result = ttk.Label(display_frame, textvariable=result_var)
label_result_title = ttk.Label(display_frame, text="Результат проверки:")

main_frame.grid(row=0, column=0)
buttons_frame.grid(row=0, column=0, sticky="nw", padx=(0,20))
btn_get.grid(row=0, column=0, pady=(0,10), ipadx=10, ipady=6)
btn_send.grid(row=1, column=0, pady=(0,10), ipadx=10, ipady=6)
display_frame.grid(row=0, column=1, sticky="nw")
lbl_fio.grid(row=0, column=0, sticky="w")
lbl_check.grid(row=1, column=0, sticky="w", pady=(4,10))
label_result_title.grid(row=2, column=0, sticky="w")
label_result.grid(row=3, column=0, sticky="w", pady=(4,0))




btn_get.config(command=get_data)
win.mainloop()
